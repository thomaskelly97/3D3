#!/usr/bin/env bash

rm my-router
rm Network
rm routing-outputA.txt 
rm routing-outputB.txt 
rm routing-outputC.txt 
rm routing-outputD.txt 
rm routing-outputE.txt 
rm routing-outputF.txt 
rm routerGOutputSteam
rm routerGOutputSteam.txt
rm router OutputStream

rm routerAOutputStream.txt 
rm routerBOutputStream.txt 
rm routerCOutputStream.txt 
rm routerDOutputStream.txt 
rm routerEOutputStream.txt 
rm routerFOutputStream.txt 
killall xterm
make